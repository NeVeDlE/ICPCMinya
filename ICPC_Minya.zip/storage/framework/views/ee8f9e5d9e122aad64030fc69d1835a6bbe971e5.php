<?php $__env->startSection('css'); ?>
    <!---Internal Owl Carousel css-->
    <link href="<?php echo e(URL::asset('assets/plugins/owl-carousel/owl.carousel.css')); ?>" rel="stylesheet">
    <!---Internal  Multislider css-->
    <link href="<?php echo e(URL::asset('assets/plugins/multislider/multislider.css')); ?>" rel="stylesheet">
    <!--- Select2 css -->
    <link href="<?php echo e(URL::asset('assets/plugins/select2/css/select2.min.css')); ?>" rel="stylesheet">
    <!-- Internal Data table css -->
    <link href="<?php echo e(URL::asset('assets/plugins/datatable/css/dataTables.bootstrap4.min.css')); ?>" rel="stylesheet"/>
    <link href="<?php echo e(URL::asset('assets/plugins/datatable/css/buttons.bootstrap4.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(URL::asset('assets/plugins/datatable/css/responsive.bootstrap4.min.css')); ?>" rel="stylesheet"/>
    <link href="<?php echo e(URL::asset('assets/plugins/datatable/css/jquery.dataTables.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(URL::asset('assets/plugins/datatable/css/responsive.dataTables.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(URL::asset('assets/plugins/select2/css/select2.min.css')); ?>" rel="stylesheet">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('page-header'); ?>
    <!-- breadcrumb -->
    <div class="breadcrumb-header justify-content-between">
        <div class="my-auto">
            <div class="d-flex">
                <h4 class="content-title mb-0 my-auto">Requests</h4>
            </div>
        </div>
        <div class="d-flex my-xl-auto right-content">
        </div>
    </div>
    <!-- breadcrumb -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>
    <?php if(session()->has('Edit')): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <strong><?php echo e(session()->get('Edit')); ?></strong>
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
    <?php endif; ?>
    <?php if(session()->has('Update')): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <strong><?php echo e(session()->get('Update')); ?></strong>
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
    <?php endif; ?>
    <?php if(session()->has('Search')): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <strong><?php echo e(session()->get('Search')); ?></strong>
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
    <?php endif; ?>
    <?php if(session()->has('Notify')): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <strong><?php echo e(session()->get('Notify')); ?></strong>
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
    <?php endif; ?>
    <?php if(session()->has('Excel')): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <strong><?php echo e(session()->get('Excel')); ?></strong>
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
    <?php endif; ?>
    <!-- row -->
    <div class="row">

        <div class="col-xl-12">
            <div class="card mg-b-20">
                <div class="card-header pb-0">
                    <div class="d-flex justify-content-between">
                        <h4 class="card-title mg-b-0">Requests</h4>
                        <i class="mdi mdi-dots-horizontal text-gray"></i>
                    </div>

                </div>
                <div class="card-header pb-0">

                    <form action="<?php echo e(route('Search')); ?>" method="get" autocomplete="off">
                        <?php echo e(csrf_field()); ?>


                        <div class="row">

                            <div class="col-lg-3 mg-t-20 mg-lg-t-0" id="type">
                                <p class="mg-b-10">Choose Training</p><select class="form-control select2"
                                                                              name="training"
                                                                              required>
                                    <option value="<?php echo e($trainID ?? 'Choose Training'); ?>" selected>
                                        <?php echo e($training ?? 'Choose Training'); ?>

                                    </option>
                                    <?php $__currentLoopData = $trainings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $train): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                        <option value="<?php echo e($train['id']); ?>"><?php echo e($train['name']); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                </select>
                            </div><!-- col-4 -->
                            <div class="col-lg-3 mg-t-20 mg-lg-t-0" id="status">
                                <p class="mg-b-10">Choose Status</p><select class="form-control select2" name="type"
                                                                            required>
                                    <option value="<?php echo e($type ?? 'Choose Status'); ?>" selected>
                                        <?php if(isset($type)): ?>
                                            <?php if($type==1): ?>
                                                Accepted
                                            <?php elseif($type==2): ?>
                                                Pending
                                            <?php elseif($type==3): ?>
                                                Banned
                                            <?php else: ?>
                                                Choose Status
                                            <?php endif; ?>
                                        <?php else: ?>
                                            Choose Status
                                        <?php endif; ?>
                                    </option>

                                    <option value="1">Accepted</option>
                                    <option value="2">Pending</option>
                                    <option value="3">Banned</option>

                                </select>
                            </div><!-- col-4 -->


                        </div>
                        <br>

                        <div class="row" style="margin-bottom: 20px">
                            <div class="col-sm-1 col-md-1">
                                <button class="btn btn-primary btn-block" type="submit">Search</button>
                            </div>
                        </div>
                    </form>

                </div>
                <?php if(isset($requests)): ?>
                    <?php if(isset($trainID)): ?>
                        <div class="card-body">
                            <div class="row">
                                <div class="col-3">

                                    <a class="btn ripple btn-indigo btn-block btn-rounded" data-target="#modaldemo1"
                                       data-toggle="modal"
                                       href="">Accept all from Minya in this training</a>
                                </div>
                                <div class="col-3">

                                    <a class="btn ripple btn-info btn-block btn-rounded" data-target="#modaldemo4"
                                       data-toggle="modal"
                                       href="">Accept all requests in this training</a>
                                </div>
                                <div class="col-3">

                                    <a class="btn ripple btn-warning btn-block btn-rounded" data-target="#modaldemo5"
                                       data-toggle="modal"
                                       href="">Decline all requests in this training</a>
                                </div>
                                <div class="col-3">

                                    <a class="btn ripple btn-success btn-block btn-rounded"
                                       href="<?php echo e(route('export')); ?>">Excel Sheet</a>
                                </div>

                            </div>
                            <div class="row" style="margin-top: 20px">
                                <div class="col-3">

                                    <a class="btn ripple btn-light btn-block btn-rounded"
                                       href="<?php echo e(URL::route('Notify', [$trainID])); ?>">Notify Accepted Students in this
                                        Training</a>
                                </div>
                            </div>
                        </div>
                    <?php endif; ?>

                    <div class="table-responsive">
                        <table id="example1" class="table text-md-nowrap">
                            <thead>
                            <tr>
                                <th class="border-bottom-0">ID</th>
                                <th class="border-bottom-0">Name</th>
                                <th class="border-bottom-0">University</th>
                                <th class="border-bottom-0">Faculty</th>
                                <th class="border-bottom-0">Training</th>
                                <th class="border-bottom-0">Year</th>
                                <th class="border-bottom-0">Status</th>
                                <th class="border-bottom-0">Operations</th>

                            </tr>
                            </thead>
                            <tbody>

                            <?php $__currentLoopData = $requests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $request): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($request['id']); ?></td>
                                    <td><?php echo e($request['name']); ?></td>
                                    <?php if($request['university']==1): ?>
                                        <td class="text-success">Minya</td>
                                    <?php else: ?>
                                        <td class="text-warning">Other</td>
                                    <?php endif; ?>

                                    <?php if($request['faculty']==1): ?>
                                        <td class="text-success">Computers and Information</td>
                                    <?php elseif($request['faculty']==2): ?>
                                        <td class="text-warning">Science</td>
                                    <?php elseif($request['faculty']==3): ?>
                                        <td class="text-warning">Engineering</td>
                                    <?php elseif($request['faculty']==4): ?>
                                        <td class="text-warning">Specific Education</td>
                                    <?php else: ?>
                                        <td class="text-warning">Other</td>
                                    <?php endif; ?>

                                    <td><?php echo e($request->item->name); ?></td>
                                    <?php if($request['year']==1): ?>
                                        <td class="text-success">First</td>
                                    <?php elseif($request['year']==2): ?>
                                        <td class="text-success">Second</td>
                                    <?php elseif($request['year']==3): ?>
                                        <td class="text-warning">Third</td>
                                    <?php elseif($request['year']==4): ?>
                                        <td class="text-warning">Fourth</td>
                                    <?php else: ?>
                                        <td class="text-danger">Fifth</td>
                                    <?php endif; ?>
                                    <?php if($request['status']==1): ?>
                                        <td class="text-success">Accepted</td>
                                    <?php elseif($request['status']==2): ?>
                                        <td class="text-warning">Pending</td>
                                    <?php else: ?>
                                        <td class="text-danger">Banned</td>
                                    <?php endif; ?>
                                    <td>
                                        <?php if($request['status']!=1): ?>
                                            <a class="modal-effect btn-lg btn-success" data-effect="effect-scale"

                                               data-id="<?php echo e($request['id']); ?>"
                                               data-name="<?php echo e($request['name']); ?>"
                                               data-toggle="modal"
                                               href="#modaldemo2"
                                               title="accept"><i class="fa fa-check"></i></a>
                                        <?php endif; ?>
                                        <?php if($request['status']!=3): ?>
                                            <a class="modal-effect btn-lg  btn-danger" data-effect="effect-scale"

                                               data-id="<?php echo e($request['id']); ?>" data-name="<?php echo e($request['name']); ?>"
                                               data-toggle="modal"
                                               href="#modaldemo3" title="delete"><i class="fa fa-times"></i></a>
                                        <?php endif; ?></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </tbody>

                        </table>
                        <?php echo e($requests->appends(['training'=>$trainID?? 'Choose Training', 'type'=>$type??'Choose Status'])->links('vendor.pagination.custom')); ?>


                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>

    </div>
    <!-- row closed -->
    </div>
    <!-- Container closed -->
    </div>
    <!-- main-content closed -->

    <!-- Large Modal -->
    <div class="modal" id="modaldemo1">
        <div class="modal-dialog modal-lg" role="document">
            <div class="modal-content modal-content-demo">
                <div class="modal-header">
                    <h6 class="modal-title">Accept all from minya in this training</h6>
                    <button aria-label="Close" class="close" data-dismiss="modal" type="button"><span
                            aria-hidden="true">&times;</span></button>
                </div>
                <form action="/requests/update" method="post" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <?php echo e(method_field('patch')); ?>


                    <div class="modal-body">

                        <div class="form-group">
                            <label for="">: Training's Name</label>
                            <input type="text" class="form-control" id="status" name="status" value="4" hidden>
                            <input type="text" class="form-control" id="id" name="id" value="<?php echo e($trainID??''); ?>" hidden>
                            <input type="text" class="form-control" id="name" name="name" value="<?php echo e($training??''); ?>"
                                   disabled>
                        </div>

                    </div>
                    <div class="modal-footer">
                        <button class="btn ripple btn-success" type="submit">Accept</button>
                        <button class="btn ripple btn-danger" data-dismiss="modal" type="button">Close</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <!--End Large Modal -->
    <!-- edit modal -->
    <div class="modal" id="modaldemo2">
        <div class="modal-dialog" role="document">
            <div class="modal-content modal-content-demo">
                <div class="modal-header">
                    <h6 class="modal-title">Accept a Trainee</h6>
                    <button aria-label="Close" class="close" data-dismiss="modal" type="button"><span
                            aria-hidden="true">&times;</span></button>
                </div>
                <form action="/requests/update" method="post" enctype="multipart/form-data" autocomplete="off">
                    <?php echo e(method_field('patch')); ?>

                    <?php echo e(csrf_field()); ?>

                    <div class="modal-body">
                        <div class="form-group">
                            <input type="hidden" name="status" id="status" value="1">
                            <input type="hidden" name="id" id="id" value="">
                            <label for="">: Trainee's Name</label>
                            <input type="text" class="form-control" id="name" name="name" disabled>
                        </div>

                    </div>
                    <div class="modal-footer">
                        <button class="btn ripple btn-success" type="submit">Accept</button>
                        <button class="btn ripple btn-secondary" data-dismiss="modal" type="button">Close</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <!--end edit modal -->
    <!-- delete modal -->
    <div class="modal" id="modaldemo3">
        <div class="modal-dialog" role="document">
            <div class="modal-content modal-content-demo">
                <div class="modal-header">
                    <h6 class="modal-title">Ban a Trainee</h6>
                    <button aria-label="Close" class="close" data-dismiss="modal" type="button"><span
                            aria-hidden="true">&times;</span></button>
                </div>
                <form action="/requests/update" method="post" enctype="multipart/form-data" autocomplete="off">
                    <?php echo e(method_field('patch')); ?>

                    <?php echo e(csrf_field()); ?>

                    <div class="modal-body">
                        <div class="form-group">
                            <input type="hidden" name="status" id="status" value="3">
                            <input type="hidden" name="id" id="id" value="">
                            <label for="">: Trainee's Name</label>
                            <input type="text" class="form-control" id="name" name="name" disabled>
                        </div>

                    </div>
                    <div class="modal-footer">
                        <button class="btn ripple btn-danger" type="submit">Ban</button>
                        <button class="btn ripple btn-secondary" data-dismiss="modal" type="button">Close</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <!-- end delete modal -->

    <!-- Large Modal -->
    <div class="modal" id="modaldemo4">
        <div class="modal-dialog modal-lg" role="document">
            <div class="modal-content modal-content-demo">
                <div class="modal-header">
                    <h6 class="modal-title">Accept all requests in this training</h6>
                    <button aria-label="Close" class="close" data-dismiss="modal" type="button"><span
                            aria-hidden="true">&times;</span></button>
                </div>
                <form action="/requests/update" method="post" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <?php echo e(method_field('patch')); ?>


                    <div class="modal-body">

                        <div class="form-group">
                            <label for="">: Training's Name</label>
                            <input type="text" class="form-control" id="status" name="status" value="5" hidden>
                            <input type="text" class="form-control" id="id" name="id" value="<?php echo e($trainID??''); ?>" hidden>
                            <input type="text" class="form-control" id="name" name="name" value="<?php echo e($training??''); ?>"
                                   disabled>
                        </div>

                    </div>
                    <div class="modal-footer">
                        <button class="btn ripple btn-success" type="submit">Accept All</button>
                        <button class="btn ripple btn-danger" data-dismiss="modal" type="button">Close</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <!--End Large Modal -->
    <!-- Large Modal -->
    <div class="modal" id="modaldemo5">
        <div class="modal-dialog modal-lg" role="document">
            <div class="modal-content modal-content-demo">
                <div class="modal-header">
                    <h6 class="modal-title">Decline all requests in this training</h6>
                    <button aria-label="Close" class="close" data-dismiss="modal" type="button"><span
                            aria-hidden="true">&times;</span></button>
                </div>
                <form action="/requests/update" method="post" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <?php echo e(method_field('patch')); ?>


                    <div class="modal-body">

                        <div class="form-group">
                            <label for="">: Training's Name</label>
                            <input type="text" class="form-control" id="status" name="status" value="6" hidden>
                            <input type="text" class="form-control" id="id" name="id" value="<?php echo e($trainID??''); ?>" hidden>
                            <input type="text" class="form-control" id="name" name="name" value="<?php echo e($training??''); ?>"
                                   disabled>
                        </div>

                    </div>
                    <div class="modal-footer">
                        <button class="btn ripple btn-warning" type="submit">Decline All</button>
                        <button class="btn ripple btn-danger" data-dismiss="modal" type="button">Close</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <!--End Large Modal -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
    <!--Internal  Datepicker js -->
    <script src="<?php echo e(URL::asset('assets/plugins/jquery-ui/ui/widgets/datepicker.js')); ?>"></script>
    <!-- Internal Select2 js-->
    <script src="<?php echo e(URL::asset('assets/plugins/select2/js/select2.min.js')); ?>"></script>
    <!-- Internal Modal js-->
    <script src="<?php echo e(URL::asset('assets/js/modal.js')); ?>"></script>
    <!-- Internal Data tables -->
    <script src="<?php echo e(URL::asset('assets/plugins/treeview/treeview.js')); ?>"></script>
    <!--Internal  Notify js -->
    <script src="<?php echo e(URL::asset('assets/plugins/notify/js/notifIt.js')); ?>"></script>
    <script src="<?php echo e(URL::asset('assets/plugins/notify/js/notifit-custom.js')); ?>"></script>
    <script src="<?php echo e(URL::asset('assets/plugins/datatable/js/jquery.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(URL::asset('assets/plugins/datatable/js/dataTables.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(URL::asset('assets/plugins/datatable/js/dataTables.responsive.min.js')); ?>"></script>
    <script src="<?php echo e(URL::asset('assets/plugins/datatable/js/responsive.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(URL::asset('assets/plugins/datatable/js/jquery.dataTables.js')); ?>"></script>
    <script src="<?php echo e(URL::asset('assets/plugins/datatable/js/dataTables.bootstrap4.js')); ?>"></script>
    <script src="<?php echo e(URL::asset('assets/plugins/datatable/js/dataTables.buttons.min.js')); ?>"></script>
    <script src="<?php echo e(URL::asset('assets/plugins/datatable/js/buttons.bootstrap4.min.js')); ?>"></script>
    <script src="<?php echo e(URL::asset('assets/plugins/datatable/js/jszip.min.js')); ?>"></script>
    <script src="<?php echo e(URL::asset('assets/plugins/datatable/js/pdfmake.min.js')); ?>"></script>
    <script src="<?php echo e(URL::asset('assets/plugins/datatable/js/vfs_fonts.js')); ?>"></script>
    <script src="<?php echo e(URL::asset('assets/plugins/datatable/js/buttons.html5.min.js')); ?>"></script>
    <script src="<?php echo e(URL::asset('assets/plugins/datatable/js/buttons.print.min.js')); ?>"></script>
    <script src="<?php echo e(URL::asset('assets/plugins/datatable/js/buttons.colVis.min.js')); ?>"></script>
    <script src="<?php echo e(URL::asset('assets/plugins/datatable/js/dataTables.responsive.min.js')); ?>"></script>
    <script src="<?php echo e(URL::asset('assets/plugins/datatable/js/responsive.bootstrap4.min.js')); ?>"></script>
    <!--Internal  Datatable js -->
    <script src="<?php echo e(URL::asset('assets/js/table-data.js')); ?>"></script>
    <script>
        $('#modaldemo2').on('show.bs.modal', function (event) {
            var button = $(event.relatedTarget)
            var id = button.data('id')
            var name = button.data('name')
            var tag = button.data('tag')
            var mentor = button.data('mentor')

            var date = button.data('date')
            var description = button.data('description')
            var modal = $(this)

            modal.find('.modal-body #id').val(id);
            modal.find('.modal-body #name').val(name);
            modal.find('.modal-body #date').val(date);
            modal.find('.modal-body #tag').val(tag);
            modal.find('.modal-body #mentor').val(mentor);
            modal.find('.modal-body #description').val(description);
        });
    </script>
    <script>
        $('#modaldemo3').on('show.bs.modal', function (event) {
            var button = $(event.relatedTarget)
            var id = button.data('id')
            var name = button.data('name')

            var modal = $(this)
            modal.find('.modal-body #id').val(id);
            modal.find('.modal-body #name').val(name);
        });
    </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\SHAHER\Desktop\ICPC_Minya\resources\views/Admin_pages/Requests/Requests.blade.php ENDPATH**/ ?>