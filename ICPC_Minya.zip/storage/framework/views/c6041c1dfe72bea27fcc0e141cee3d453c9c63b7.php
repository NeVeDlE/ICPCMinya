<!-- Footer opened -->
	<div class="main-footer ht-40">
		<div class="container-fluid pd-t-0-f ht-100p">
			<span>Copyright © 2021 <a href="https://www.facebook.com/icpcminya/">ICPC Minya University</a>. Designed by <a href="https://github.com/NeVeDlE">NeVeDlE</a> All rights reserved.</span>
		</div>
	</div>
<!-- Footer closed -->
<?php /**PATH C:\Users\SHAHER\Desktop\ICPC_Minya\resources\views/layouts/footer.blade.php ENDPATH**/ ?>