<?php $__env->startSection('css'); ?>
    <!---Internal Owl Carousel css-->
    <link href="<?php echo e(URL::asset('assets/plugins/owl-carousel/owl.carousel.css')); ?>" rel="stylesheet">
    <!---Internal  Multislider css-->
    <link href="<?php echo e(URL::asset('assets/plugins/multislider/multislider.css')); ?>" rel="stylesheet">
    <!--- Select2 css -->
    <link href="<?php echo e(URL::asset('assets/plugins/select2/css/select2.min.css')); ?>" rel="stylesheet">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('page-header'); ?>
    <!-- breadcrumb -->
    <div class="breadcrumb-header justify-content-between">
        <div class="my-auto">
            <div class="d-flex">
                <h4 class="content-title mb-0 my-auto">Home Page</h4><span class="text-muted mt-1 tx-13 mr-2 mb-0">/ User Pages Controller</span>
            </div>
        </div>
        <div class="d-flex my-xl-auto right-content">
        </div>
    </div>
    <!-- breadcrumb -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>
    <?php if(session()->has('edit')): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <strong><?php echo e(session()->get('edit')); ?></strong>
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
    <?php endif; ?>
    <!-- row -->
    <div class="row">
        <div class="col-sm-6 col-md-6">
            <div class="card custom-card">
                <div class="card-body">
                    <div>
                        <p style="text-align: center">Use this to change Background Photo on the Home Page</p>
                    </div>
                    <a class="btn ripple btn-indigo btn-block btn-rounded" data-target="#modaldemo1" data-toggle="modal"
                       href="">Change Photo</a>
                </div>
            </div>
        </div>

        <div class="col-sm-6 col-md-6">
            <div class="card custom-card">
                <div class="card-body">
                    <div>
                        <p style="text-align: center">Use this to change Header 1 and Header 2 in the HomePage</p>
                    </div>
                    <a class="btn ripple btn-info btn-block btn-rounded" data-target="#modaldemo2" data-toggle="modal"
                       href="">Change Headers</a>
                </div>
            </div>
        </div>
    </div>
    <!-- row closed -->
    </div>
    <!-- Container closed -->
    </div>
    <!-- main-content closed -->

    <!-- Large Modal -->
    <div class="modal" id="modaldemo1">
        <div class="modal-dialog modal-lg" role="document">
            <div class="modal-content modal-content-demo">
                <div class="modal-header">
                    <h6 class="modal-title">Large Modal</h6>
                    <button aria-label="Close" class="close" data-dismiss="modal" type="button"><span
                            aria-hidden="true">&times;</span></button>
                </div>
                <form action="homeController/update" method="post" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <?php echo e(method_field("patch")); ?>

                    <div class="modal-body">

                        <div class="form-group">
                            <input type="text" class="form-control" id="id" name="id" hidden value="1">
                        </div>

                        <div class="form-group">
                            <label for="">: Upload the new Background photo</label>
                            <input type="file" class="form-control" id="background" name="background" required>
                        </div>

                    </div>
                    <div class="modal-footer">
                        <button class="btn ripple btn-success" type="submit">Change</button>
                        <button class="btn ripple btn-danger" data-dismiss="modal" type="button">Close</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <!--End Large Modal -->
    <!-- Large Modal -->
    <div class="modal" id="modaldemo2">
        <div class="modal-dialog modal-lg" role="document">
            <div class="modal-content modal-content-demo">
                <div class="modal-header">
                    <h6 class="modal-title">Large Modal</h6>
                    <button aria-label="Close" class="close" data-dismiss="modal" type="button"><span
                            aria-hidden="true">&times;</span></button>
                </div>
                <form action="homeController/update" method="post" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <?php echo e(method_field("patch")); ?>

                    <div class="modal-body">

                        <div class="form-group">
                            <input type="text" class="form-control" id="id" name="id" hidden value="2">
                        </div>

                        <div class="form-group">
                            <label for="">: First Header</label>
                            <input type="text" class="form-control" id="first" name="first" required value="<?php echo e($page->h1); ?>">
                        </div>
                        <div class="form-group">
                            <label for="">: Second Header</label>
                            <input type="text" class="form-control" id="second" name="second" required value="<?php echo e($page->h2); ?>">
                        </div>

                    </div>
                    <div class="modal-footer">
                        <button class="btn ripple btn-success" type="submit">Change</button>
                        <button class="btn ripple btn-danger" data-dismiss="modal" type="button">Close</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <!--End Large Modal -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
    <!--Internal  Datepicker js -->
    <script src="<?php echo e(URL::asset('assets/plugins/jquery-ui/ui/widgets/datepicker.js')); ?>"></script>
    <!-- Internal Select2 js-->
    <script src="<?php echo e(URL::asset('assets/plugins/select2/js/select2.min.js')); ?>"></script>
    <!-- Internal Modal js-->
    <script src="<?php echo e(URL::asset('assets/js/modal.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\SHAHER\Desktop\ICPC_Minya\resources\views/Admin_pages/home_page.blade.php ENDPATH**/ ?>